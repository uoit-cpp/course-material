#include <iostream>
using std::cout;
using std::endl;
using std::cin;

template <typename T>
class loc
{
  protected:
  T _x, _y;

  public:
  loc() {}
  loc(T x, T y)
    : _x(x), _y(y)
  {}

  T x() const { return _x; }
  T y() const { return _y; }
  
  void multiplyBy2();
};

template <typename T>
void loc<T>::multiplyBy2()
{
  _x *= 2;
  _y *= 2;
}

template <>
void loc<int>::multiplyBy2()
{
  cout << "Specialization called." << endl;
  _x = (_x << 2);
  _y = (_y << 2);
}


int main()
{
  loc<float> l(1.2, 3.4);
  l.multiplyBy2();
  cout << l.x() << ", " << l.y() << endl;

  loc<int> l2(2,3);
  l2.multiplyBy2();
  cout << l2.x() << ", " << l2.y() << endl;
  
  return 0;
}
