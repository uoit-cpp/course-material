#include <iostream>
using std::cout;
using std::endl;
using std::ostream;

//Class for a pair of values of type T:
template<class T, class U>
class Pair
{
public:
    Pair(const T& firstValue, const U& secondValue);

    void setFirst(const T& newValue);
    void setSecond(const U& newValue);
    
    const T& getFirst( ) const;
    const U& getSecond( ) const;
    
private:
    T first;
    U second;
};

template<class T, class U>
Pair<T,U>::Pair(const T& firstValue, const U& secondValue)
{
    first = firstValue;
    second = secondValue;
}

template<class T, class U>
void Pair<T,U>::setFirst(const T& newValue)
{
    first = newValue;
}

template<class T, class U>
const T& Pair<T, U>::getFirst() const
{
    return first;
}

template<class T, class U>
void Pair<T, U>::setSecond(const U& newValue)
{
    second = newValue;
}

template<class T, class U>
const U& Pair<T,U>::getSecond() const
{
    return second;
}

template<class T, class U>
ostream& operator<<(ostream& os, const Pair<T,U>& p)
{
  os << "[" << endl
     << "1: " << p.getFirst() << endl
     << "2: " << p.getSecond() << endl
     << "]";
  return os;
}

int main( )
{
    Pair<char, int> p('A', 12);
    
    cout << "First is " << p.getFirst() << endl;
    p.setFirst('Z');
    cout << "First changed to " << p.getFirst() << endl;

    cout << "Second is " << p.getSecond() << endl;
    p.setSecond(2234);
    cout << "Second changed to " << p.getSecond( ) << endl;

    cout << p << endl;

    return 0;
}
