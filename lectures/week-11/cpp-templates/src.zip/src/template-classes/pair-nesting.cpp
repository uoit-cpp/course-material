#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::ostream;
using std::string;

//Class for a pair of values of type T:
template<class T, class U>
class Pair
{
public:
    Pair() {}
    Pair(const T& firstValue, const U& secondValue);

    void setFirst(const T& newValue);
    void setSecond(const U& newValue);
    
    const T& getFirst( ) const;
    const U& getSecond( ) const;
    
private:
    T first;
    U second;
};

template<class T, class U>
Pair<T,U>::Pair(const T& firstValue, const U& secondValue)
{
    first = firstValue;
    second = secondValue;
}

template<class T, class U>
void Pair<T,U>::setFirst(const T& newValue)
{
    first = newValue;
}

template<class T, class U>
const T& Pair<T, U>::getFirst() const
{
    return first;
}

template<class T, class U>
void Pair<T, U>::setSecond(const U& newValue)
{
    second = newValue;
}

template<class T, class U>
const U& Pair<T,U>::getSecond() const
{
    return second;
}

template<class T, class U>
ostream& operator<<(ostream& os, const Pair<T,U>& p)
{
  os << "[" << endl
     << "1: " << p.getFirst() << endl
     << "2: " << p.getSecond() << endl
     << "]";
  return os;
}

int main( )
{
  int studentnumber = 10032120;
  Pair<string, float> name_gpa("John",2.3);
  Pair<int, Pair<string, float> > record(studentnumber, name_gpa);

  typedef Pair<string, float> ng;
  typedef Pair<int, ng> rng;

  rng record1(12, ng("Saira", 3.5));
  cout << record1 << endl;
  
  return 0;
}
