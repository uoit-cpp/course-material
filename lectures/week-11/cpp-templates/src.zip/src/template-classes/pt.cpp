#include <iostream>
using std::ostream;
using std::cout;
using std::endl;

class pt
{
  protected:
  float _x, _y;

  public:
  pt(float x, float y)
    : _x(x), _y(y)
    {}

  float& x() { return _x; }  
  float& y() { return _y; }
  const float& x() const { return _x; }  
  const float& y() const { return _y; }

  float d2();
  
  friend ostream& operator<<(ostream& os, const pt& p);  
};

float pt::d2()
{
  return _x*_x + _y*_y;
}

ostream& operator<<(ostream& os, const pt& p)
{
  os << "(" << p.x() << "," << p.y() << ")";

  return os;
}

int main()
{
  pt a(1.0, 2.5);
  cout << a.d2() << endl;
  cout << a << endl;
  
  return 0;
}
