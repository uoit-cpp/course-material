#include <iostream>
using std::ostream;
using std::cout;
using std::endl;

template <typename T>
class pt
{
  protected:
  T _x, _y;

  public:
  pt(T x, T y)
    : _x(x), _y(y)
    {}

  T& x() { return _x; }  
  T& y() { return _y; }
  const T& x() const { return _x; }  
  const T& y() const { return _y; }

  T d2();
  
  template<typename U>
  friend ostream& operator<<(ostream& os, const pt<U>& p);  
};

template <typename T>
T pt<T>::d2()
{
  return _x*_x + _y*_y;  
}

template <typename K>
ostream& operator<<(ostream& os, const pt<K>& p)
{
  os << "(" << p.x() << "," << p.y() << ")";

  return os;
}

int main()
{
  pt<float> a(1, 2.5);
  cout << a.d2() << endl;
  cout << a << endl;
  
  return 0;
}
