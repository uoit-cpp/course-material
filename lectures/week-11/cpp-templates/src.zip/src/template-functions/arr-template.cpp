#include <iostream>

template <typename T>
T sum(T a[], int n)
{
  T sum = 0;
  for (int i=0; i<n; ++i) {
    sum += a[i];
  }
  return sum;
}

int main()
{
  using std::cout;
  using std::endl;

  float a[] = {1, 2, 3};
  int arr_sum = sum<float>(a, 3);
  cout << arr_sum << endl;
  
  return 0;
}
