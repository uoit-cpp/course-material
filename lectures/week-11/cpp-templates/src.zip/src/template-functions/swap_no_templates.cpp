#include <iostream>

void swap(int& i, int& j)
{
    int temp = i;
    i = j;
    j = temp;
}

int main()
{
  using std::cout;
  using std::endl;

  int i = 1, j = 2;
  swap(i, j);
  cout << "i=" << i << endl;
  cout << "j=" << j << endl;
  
  return 0;
}



//   float f = 1, f = 2;
//   std::cout << "f = " << f << ", g = " << g << std::endl;
//   swap(f, g);
//   std::cout << "f = " << f << ", g = " << g << std::endl;


// // swap() function that works for float's
// void swap(float& i, float& j)
// {
//     float temp = i;
//     i = j;
//     j = i;
// }
