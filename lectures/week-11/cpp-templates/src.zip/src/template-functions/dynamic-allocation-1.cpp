#include <iostream>
using std::cout;
using std::endl;

template<class T>
T* create_array(int n)
{
  T* a = new T [n];
  return a;
}

int main()
{
  double* a = create_array<double>(5);
  for (int i=0; i<5; ++i) {
    a[i] = i * 2;
  }

  for (int i=0; i<5; ++i) {
    cout << a[i] << endl;
  }

  delete[] a;
  
  return 0;
}
