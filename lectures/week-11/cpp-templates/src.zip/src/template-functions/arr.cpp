#include <iostream>

int sum(int a[], int n)
{
  int sum = 0;
  for (int i=0; i<n; ++i) {
    sum += a[i];
  }
  return sum;
}

int main()
{
  using std::cout;
  using std::endl;

  int a[] = {1, 2, 3};
  int arr_sum = sum(a, 3);

  cout << "sum = " << arr_sum << endl;
  
  return 0;
}
