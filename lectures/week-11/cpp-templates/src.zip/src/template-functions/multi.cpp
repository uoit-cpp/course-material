#include <iostream>

void prn(int i, float j, char k)
{
  using std::cout;
  using std::endl;

  cout << i << endl;
  cout << j << endl;
  cout << k << endl;
}

int main()
{
  prn(1,2.5,'A');

  return 0;
}

