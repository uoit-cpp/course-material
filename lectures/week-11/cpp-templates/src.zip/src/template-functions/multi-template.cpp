#include <iostream>

template <typename K, typename L, typename M>
void prn(K i, L j, M k)
{
  using std::cout;
  using std::endl;

  cout << i << endl;
  cout << j << endl;
  cout << k << endl;
}

int main()
{
  prn<int, float, char>(1,2.5,'A');
  prn<int, char, float>(1,'A',3.2);

  float n=1;
  prn<int, int*, char>(1,&n,'A');

  
  return 0;
}

