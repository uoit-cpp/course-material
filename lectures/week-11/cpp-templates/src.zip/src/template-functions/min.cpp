#include <iostream>

int min(int a, int b)
{
  if (a < b) return a;
  return b;
}

int main()
{
  using std::cout;
  using std::endl;

  cout << min(1,2) << endl;
  
  return 0;
}
