#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;

template<class T>
T* create_array(int n)
{
  T* a = new T [n];
  return a;
}

int main()
{
  string* movies = create_array<string>(2);
  movies[0] = "Casablanca";
  movies[1] = "On the Waterfront";
  
  for (int i=0; i<2; ++i) {
    cout << movies[i] << endl;
  }

  delete[] movies;
  
  return 0;
}
