#include <iostream>

template <typename T>
void swap(T& i, T& j)
{
    T temp = i;
    i = j;
    j = temp;
}

int main()
{
  using std::cout;
  using std::endl;

  int i = 1, j = 2;
  swap<int>(i, j);
  cout << "i=" << i << endl;
  cout << "j=" << j << endl;
  
  return 0;
}
