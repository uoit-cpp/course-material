#include <iostream>

template <typename T>
T min(T a, T b)
{
  if (a < b) return a;
  return b;
}

int main()
{
  using std::cout;
  using std::endl;

  cout << min<float>(1.4,2.2) << endl;
  
  return 0;
}
